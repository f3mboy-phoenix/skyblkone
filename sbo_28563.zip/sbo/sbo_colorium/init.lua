sbz_api.quests[#sbz_api.quests+1]={ type = "text", title = "Questline: Colorium", text = "????" }

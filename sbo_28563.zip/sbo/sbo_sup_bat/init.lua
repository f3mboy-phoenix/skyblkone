sbz_power.register_battery("sbo_sup_bat:super_battery", {
    description = "Super Battery",
    tiles = { "super_battery.png" },
    groups = { matter = 1 },
    battery_max = sbz_power.cjh2cj(15),
})


minetest.register_craft({
    output = "sbo_sup_bat:super_battery",
    recipe = {
        { "sbo_extrosim:raw_extrosim",  "sbo_colorium_plate:colorium_plate", "sbo_extrosim:raw_extrosim" },
        { "sbo_colorium_plate:colorium_plate", "sbz_power:advanced_battery", "sbo_colorium_plate:colorium_plate" },
        { "sbo_colorium_circuit:colorium_circuit",  "sbo_extrosim_circuit:extrosim_circuit", "sbo_colorium_circuit:colorium_circuit" }
    }
})
